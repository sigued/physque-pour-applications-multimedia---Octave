function [retval] = cdmCylindre (hauteur)
  
  retval = [0, 0, hauteur/2];

endfunction
