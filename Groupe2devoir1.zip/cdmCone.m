function retval = cdmCone (hauteur_cone, hauteur_cyl)
  
  retval = [0,0,hauteur_cyl+hauteur_cone/4];

endfunction
